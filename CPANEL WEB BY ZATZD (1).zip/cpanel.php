<?php
session_start();
if ($_SESSION["role"] !== "user") {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Buat Akun & Server Pterodactyl</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
        :root {
            --primary: #00b4ff;
            --secondary: #7c3aed;
            --dark: #0f0f23;
            --darker: #06061a;
            --light: #e6f3ff;
            --cosmic-accent: #ff6b9d;
            --stellar-glow: rgba(0, 180, 255, 0.4);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: radial-gradient(ellipse at center, var(--darker) 0%, var(--dark) 100%);
            color: var(--light);
            font-family: 'Exo 2', sans-serif;
            min-height: 100vh;
            padding: 15px;
            background-attachment: fixed;
            overflow-x: hidden;
            position: relative;
        }

        /* Animated space background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(2px 2px at 25px 35px, white, transparent),
                radial-gradient(1px 1px at 50px 75px, white, transparent),
                radial-gradient(1px 1px at 95px 45px, white, transparent),
                radial-gradient(2px 2px at 135px 85px, white, transparent);
            background-repeat: repeat;
            background-size: 180px 120px;
            animation: starfield 6s ease-in-out infinite alternate;
            z-index: -2;
            opacity: 0.4;
        }

        @keyframes starfield {
            0% { opacity: 0.2; transform: translateY(0px); }
            100% { opacity: 0.6; transform: translateY(-2px); }
        }

        .server-container {
            max-width: 100%;
            width: 100%;
            margin: 20px auto;
            background: rgba(15, 15, 35, 0.95);
            padding: 25px;
            border-radius: 16px;
            border: 2px solid rgba(0, 180, 255, 0.3);
            box-shadow: 
                0 0 30px var(--stellar-glow),
                inset 0 0 20px rgba(124, 58, 237, 0.1);
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(10px);
        }

        .server-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(0, 180, 255, 0.08) 0%, transparent 70%);
            animation: cosmicRotate 25s linear infinite;
            z-index: -1;
        }

        @keyframes cosmicRotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        h2 {
            text-align: center;
            font-family: 'Orbitron', sans-serif;
            color: var(--primary);
            text-shadow: 0 0 20px rgba(0, 180, 255, 0.8);
            margin-bottom: 25px;
            font-size: 28px;
            letter-spacing: 2px;
            position: relative;
            display: block;
            width: 100%;
        }

        h2::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--primary), var(--secondary), transparent);
            border-radius: 2px;
            box-shadow: 0 0 10px var(--primary);
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary);
            font-size: 16px;
            z-index: 2;
        }

        input, select {
            width: 100%;
            padding: 14px 12px 14px 40px;
            margin: 6px 0;
            border-radius: 10px;
            border: 1px solid rgba(0, 180, 255, 0.2);
            background: rgba(20, 25, 50, 0.8);
            color: var(--light);
            font-size: 16px;
            font-family: 'Exo 2', sans-serif;
            transition: all 0.3s ease;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 
                0 0 15px rgba(0, 180, 255, 0.5),
                inset 0 2px 4px rgba(0, 0, 0, 0.3);
            background: rgba(25, 30, 60, 0.9);
        }

        label {
            display: block;
            margin-bottom: 6px;
            color: var(--primary);
            font-family: 'Orbitron', sans-serif;
            font-size: 13px;
            letter-spacing: 1px;
            text-transform: uppercase;
            font-weight: 600;
        }

        button {
            width: 100%;
            padding: 16px;
            margin-top: 25px;
            border-radius: 10px;
            border: none;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--dark);
            font-weight: bold;
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            font-size: 16px;
            text-transform: uppercase;
            box-shadow: 0 8px 20px rgba(0, 180, 255, 0.3);
        }

        button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: all 0.6s ease;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(0, 180, 255, 0.4);
        }

        button:hover::before {
            left: 100%;
        }

        button:active {
            transform: translateY(0px);
        }

        .robot-header {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 25px;
            position: relative;
        }

        .robot-icon {
            font-size: 70px;
            background: linear-gradient(135deg, var(--primary), var(--cosmic-accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            position: relative;
            animation: spaceFloat 4s ease-in-out infinite;
            filter: drop-shadow(0 0 15px rgba(0, 180, 255, 0.5));
        }

        @keyframes spaceFloat {
            0%, 100% { transform: translateY(0px) scale(1); }
            50% { transform: translateY(-8px) scale(1.05); }
        }

        .server-status {
            display: flex;
            justify-content: space-between;
            margin: 25px 0;
            position: relative;
            gap: 8px;
        }

        .status-indicator {
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: #333;
            position: relative;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.5);
            flex: 1;
            max-width: 14px;
        }

        .status-indicator::before {
            content: '';
            position: absolute;
            top: -4px;
            left: -4px;
            right: -4px;
            bottom: -4px;
            border-radius: 50%;
            opacity: 0;
            animation: cosmicPulse 2.5s infinite;
        }

        .status-indicator:nth-child(1) {
            background: #ff4757;
        }
        .status-indicator:nth-child(1)::before {
            box-shadow: 0 0 12px 4px #ff4757;
            animation-delay: 0s;
        }

        .status-indicator:nth-child(2) {
            background: #2ed573;
        }
        .status-indicator:nth-child(2)::before {
            box-shadow: 0 0 12px 4px #2ed573;
            animation-delay: 0.6s;
        }

        .status-indicator:nth-child(3) {
            background: var(--primary);
        }
        .status-indicator:nth-child(3)::before {
            box-shadow: 0 0 12px 4px var(--primary);
            animation-delay: 1.2s;
        }

        .status-indicator:nth-child(4) {
            background: var(--cosmic-accent);
        }
        .status-indicator:nth-child(4)::before {
            box-shadow: 0 0 12px 4px var(--cosmic-accent);
            animation-delay: 1.8s;
        }

        @keyframes cosmicPulse {
            0% { opacity: 0; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.3); }
            100% { opacity: 0; transform: scale(1); }
        }

        .circuit-lines {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
            opacity: 0.15;
        }

        .circuit-line {
            position: absolute;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .circuit-line.horizontal {
            height: 1px;
            width: 100%;
            animation: cosmicFlow 20s linear infinite;
        }

        .circuit-line.vertical {
            width: 1px;
            height: 100%;
            animation: cosmicFlowV 20s linear infinite;
        }

        @keyframes cosmicFlow {
            0% { transform: translateX(-100%); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateX(100%); opacity: 0; }
        }

        @keyframes cosmicFlowV {
            0% { transform: translateY(-100%); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(100%); opacity: 0; }
        }

        .tech-badge {
            position: absolute;
            right: -15px;
            top: -15px;
            background: rgba(255, 107, 157, 0.2);
            color: var(--cosmic-accent);
            padding: 8px 16px;
            transform: rotate(45deg);
            font-family: 'Orbitron', sans-serif;
            font-size: 11px;
            letter-spacing: 1px;
            border: 1px solid var(--cosmic-accent);
            box-shadow: 0 0 15px rgba(255, 107, 157, 0.4);
            text-transform: uppercase;
        }

        .server-stats {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            font-size: 11px;
            color: rgba(255, 255, 255, 0.6);
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 0.5px;
            flex-wrap: wrap;
            gap: 10px;
        }

        /* Mobile First - Tablet styles */
        @media (min-width: 768px) {
            body {
                padding: 30px;
            }
            
            .server-container {
                max-width: 500px;
                padding: 35px;
                margin: 40px auto;
            }
            
            h2 {
                font-size: 32px;
                margin-bottom: 30px;
            }
            
            .input-group {
                margin-bottom: 25px;
            }
            
            .robot-icon {
                font-size: 80px;
            }
            
            input, select {
                padding: 16px 14px 16px 45px;
            }
            
            button {
                padding: 18px;
                margin-top: 30px;
            }
        }

        /* Desktop styles */
        @media (min-width: 1024px) {
            .server-container {
                max-width: 550px;
                padding: 40px;
            }
            
            .server-stats {
                font-size: 12px;
            }
        }

        /* Touch improvements for mobile */
        @media (hover: none) and (pointer: coarse) {
            button {
                padding: 18px;
                font-size: 17px;
            }
            
            input, select {
                padding: 16px 12px 16px 40px;
                font-size: 17px;
            }
        }
  </style>
</head>
<body>
  <div class="server-container">
    <div class="circuit-lines">
      <div class="circuit-line horizontal" style="top: 20%;"></div>
      <div class="circuit-line horizontal" style="top: 40%;"></div>
      <div class="circuit-line horizontal" style="top: 60%;"></div>
      <div class="circuit-line horizontal" style="top: 80%;"></div>
      <div class="circuit-line vertical" style="left: 20%;"></div>
      <div class="circuit-line vertical" style="left: 40%;"></div>
      <div class="circuit-line vertical" style="left: 60%;"></div>
      <div class="circuit-line vertical" style="left: 80%;"></div>
    </div>
    
    <div class="tech-badge">BETA v2.0</div>
    
    <div class="robot-header">
      <i class="robot-icon fas fa-robot"></i>
    </div>
    
    <div class="server-status">
      <div class="status-indicator"></div>
      <div class="status-indicator"></div>
      <div class="status-indicator"></div>
      <div class="status-indicator"></div>
    </div>
    
    <h2>CREATE ACCOUNT + SERVER</h2>
    
    <form action="proses/proses.php" method="POST">
          <div class="input-group">
        <i class="fas fa-envelope"></i>
        <input type="email" name="emailPENERIMA" placeholder="Email Penerima" required />
      </div>
      
      <div class="input-group">
        <i class="fas fa-user"></i>
        <input type="text" name="username" placeholder="Username" required />
      </div>
      
      <div class="input-group">
        <i class="fas fa-envelope"></i>
        <input type="email" name="email" placeholder="Email" required />
      </div>
      
      <div class="input-group">
        <i class="fas fa-lock"></i>
        <input type="password" name="password" placeholder="Password" required />
      </div>

      <label><i class="fas fa-server"></i> Jenis Server (Egg)</label>
      <select name="egg" required>
        <option value="15">Node.js</option>
      </select>

      <label><i class="fas fa-globe"></i> Lokasi Server</label>
      <select name="location" required>
        <option value="1">Singapore</option>
      </select>

     <label>RAM</label>
<select name="ram" required>
  <option value="1024">1 GB</option>
  <option value="2048">2 GB</option>
  <option value="3072">3 GB</option>
  <option value="4096">4 GB</option>
  <option value="5120">5 GB</option>
  <option value="6144">6 GB</option>
  <option value="7168">7 GB</option>
  <option value="8192">8 GB</option>
  <option value="9216">9 GB</option>
  <option value="10240">10 GB</option>
  <option value="0">UNLI</option>
</select>
      <button type="submit">
        <i class="fas fa-power-off"></i> ACTIVATE SERVER
      </button>
    </form>
    
    <div class="server-stats">
      <span>SYSTEM: ONLINE</span>
      <span>NODES: 2/4</span>
      <span>LATENCY: 28ms</span>
    </div>
  </div>
</body>
</html>