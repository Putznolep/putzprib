<?php
session_start();
if ($_SESSION["role"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

$file = "../database/data.json";
$data = json_decode(file_get_contents($file), true);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_user = [
        "username" => $_POST["username"],
        "password" => $_POST["password"],
        "role" => $_POST["role"]
    ];
    $data[] = $new_user;
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    $msg = "✅ User berhasil ditambahkan!";
}
?>

<link rel="stylesheet" href="../database/style.css">
<div class="container">
  <h2>Admin Panel - <?= $_SESSION["username"] ?></h2>

  <form method="post">
    <h2>Tambah User/Admin</h2>
    <input type="text" name="username" placeholder="Username Baru" required>
    <input type="text" name="password" placeholder="Password" required>
    <select name="role" required>
      <option value="user">User</option>
      <option value="admin">Admin</option>
    </select>
    <input type="submit" value="Tambah">
    <?= isset($msg) ? "<p>$msg</p>" : "" ?>
  </form>

  <a href="../logout.php">Logout</a>
</div>